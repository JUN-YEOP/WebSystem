import logo from './logo.svg';
import './App.css';
import React, {Component} from 'react';
import ReactDOM from 'react-dom';



export default class App extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isName:"NO",
            userName: ""
        }
    }

    changeData = () => {
        this.setState(
            {
                isName: "YES",
                userName: document.getElementById('input').value
            }
        );

        ReactDOM.render( <React.StrictMode>
                <App />
            </React.StrictMode>,
            document.getElementById('root'));
    }

    render() {
        if(this.state.isName === "YES"){
            return (
                <div className="App">
                    <img src={logo} className="App-logo" alt="logo" />
                    <p>Hello, {this.state.userName}!</p>
                </div>


            )
        }
        else{
            return(
            <div className="App">
                <h1>Who are you?</h1>
                <input type='text' id='input'></input>
                <br></br>
                <button onClick={this.changeData}>OK</button>
                <br></br>
                 {/*<p>Hello, {this.state.userName}!</p>*/}
            </div>
            )


        }
    }
}
