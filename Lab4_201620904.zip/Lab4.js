function myFunction() {

    let inputText = document.getElementById("textarea").value;
    if (!inputText) return;



    let newArticle = document.createElement("article");
    newArticle.innerHTML = inputText;
    document.querySelector(".section").appendChild(newArticle);


    document.getElementById("memoCount").innerHTML = document.getElementsByTagName("article").length - 1;
    document.querySelector("#myArticle").appendChild(articleCount);

}
document.getElementById('my-btn').addEventListener('click', myFunction);