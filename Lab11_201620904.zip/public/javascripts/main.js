//
// function edit(id, title, year, url){
//     let edit_title =  document.getElementById("edit_title");
//     let edit_id = document.getElementById("edit_id");
//     let edit_year = document.getElementById("edit_year");
//     let edit_url = document.getElementById("edit_url");
//
//     edit_title.value = title;
//     edit_id.value = id;
//     edit_year.value = year;
//     edit_url.value = url;
// }

// 영화 정보 편집 페이지 이동 함수

function moveToEdit(id){
    const form = document.createElement('form');
    form.method = 'get';
    form.action = '/routes/movie/read/'+id;
    document.body.appendChild(form);
    form.submit();
}


//인기 영화 지정 함수
function updateTrendOn(id){
    const form = document.createElement('form');
    form.method = 'post';
    form.action = '/routes/movie/update/'+id;


    const hiddenField = document.createElement('input');
    hiddenField.type ='hidden';
    hiddenField.name = 'trending';
    hiddenField.value = true;

    form.appendChild(hiddenField);
    document.body.appendChild(form);
    form.submit();
}

//인기 영화 비지정 함수
function updateTrendOff(id){
    const form = document.createElement('form');
    form.method = 'post';
    form.action = '/routes/movie/update/'+id;


    const hiddenField = document.createElement('input');
    hiddenField.type ='hidden';
    hiddenField.name = 'trending';
    hiddenField.value = false;

    form.appendChild(hiddenField);
    document.body.appendChild(form);
    form.submit();
}

//삭제 요청 함수
function deleteMovie(id){

    // let list = document.getElementById('movielist');

    let deletedMovie = document.getElementById("movie"+id);
    // list.appendChild(deletedMovie);
    deletedMovie.remove();

    const form = document.createElement('form');
    form.method = 'post';
    form.action = '/routes/movie/delete/'+id;
    document.body.appendChild(form);
    form.submit();
}

//삭제 요청 함수 By Ajax
function ajaxDelete(id){
    var xhr = new XMLHttpRequest();
    xhr.onload = function(){
        // alert("삭제");
        // console.log(id);
        if(xhr.status === 200 || xhr.status === 201){
            let deletedMovie = document.getElementById("movie"+id);
            console.log(deletedMovie);
            deletedMovie.remove();

            alert("삭제 성공!");
        }else {
            alert("삭제 실패");
        }
    }
    xhr.open("POST", "/routes/movie/delete/"+ id);
    xhr.setRequestHeader("Content-Type", 'application/json');
    xhr.send();
}

