const Movie = require('../models/movie');


var express = require('express');
var router = express.Router();

//promise
router.get('/', (req, res, next)=>{
  Movie.find({}).then( (movies)=>{
    // console.log("메인페이지 랜더링\n");
    res.render('index', {movies : movies});
  }).catch((err)=>{
    // console.log("메인페이지 랜더링 에러\n");
    console.log(err);
  });
});


//callback
// router.get('/', (req, res, next) => {
//
//     Movie.find({}, function (err,movies){
//         if (err)
//             console.log(err);
//         console.log("movie 찾음");
//         res.render('index', {movies: movies});
//     });
// });

router.get('/newmovie', function (req, res, next) {
  // console.log("newmovie 랜더링\n");
  res.render('newmovie');
});

router.get('/admin', (req, res, next)=>{
  Movie.find({}).then( (movies)=>{
    // console.log("Admin 페이지 랜더링\n");
    res.render('admin', {movies : movies});
  }).catch((err)=>{
    console.log(err);
  });
});













module.exports = router;
