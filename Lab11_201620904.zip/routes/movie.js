const Movie = require('../models/movie');

var express = require('express');
var router = express.Router();

//create
router.post('/routes/movie/create',function(req, res, next) {
    // console.log("영화 저장\n");
    // console.log(req.body.title);
    const movie = new Movie({
        title: req.body.title,
        year: req.body.year,
        url: req.body.url
    });
    movie.save((err) => {
        res.redirect('/');
    });
});


//read
router.get('/routes/movie/read/:id', function(req, res, next) {
    console.log(req.params.id);

    Movie.findOne({_id : req.params.id}).then((movie)=>{
        console.log(movie);
        res.render('editmovie', {movie : movie});
    }).catch((err)=>{
        console.log(err);
    });
});

//update
router.post('/routes/movie/update/:id',function(req, res, next) {

    console.log("영화 업데이트");
    console.log(req.body);
    console.log(req.params);
    Movie.findByIdAndUpdate(req.params.id, req.body, (err,movie)=>{
        res.redirect('/admin');
    });
});

// Delete
router.post('/routes/movie/delete/:id', (req, res, next)=>{
    console.log(req.params.id);
    console.log("\n삭제!!");

    Movie.deleteOne({_id:req.params.id}, (err,movie)=>{
        res.redirect('/admin');
    })
});

// Delete By Ajax
// router.post('/routes/movie/delete/:id', (req, res, next)=>{
//     console.log("req.params = " +req.params);
//     console.log("req.body = " + req.body);
//     console.log("\n삭제 By Ajax!!");
//
//     Movie.deleteOne({_id : req.params.id}).then((result)=>{
//         var response = {
//             success : true
//         }
//         res.status(200).json(response);
//     }).catch((err)=>{
//         var response = {
//             success : false
//         }
//         res.status(500).json(response);
//     });
//
// });




module.exports = router;