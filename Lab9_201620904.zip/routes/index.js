var express = require('express');
var router = express.Router();
var fs = require('fs');
var util = require('util');
var path = require('path');

/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index.pug', {title: 'Express'});
});


/* POST result page. */
router.post('/result', function (req, res) {

    var body = req.body;

    // console.log("\n"+req.body.title.length+"\n");
    // console.log("\n"+req.body.cast+"\n");
    // console.log("\n"+req.body.poster_URL+"\n");
    // console.log("\n"+req.body.genre+"\n");
    if (req.body.title.length === 0 || body.cast.length === 0 || body.poster_URL.length === 0 || body.genre.length === 0) {

        res.send('입력 누락.');
    } else {

        //util.promisify 사용

        const targetURL = req.body.poster_URL;
        const targetPath = path.join(process.cwd(), `public`, targetURL);

        // fs.stat(`${targetPath}`, (err,stats)=>{
        //    return new Promise((resolve)=>{
        //
        //    })
        // });

        const stat = util.promisify(fs.stat);
        stat(`${targetPath}`).then(function () {
            console.log("Movie info is successfully registered.\n");
            res.render('result.pug', {data: req.body});
        }).catch(function (err) {
            console.log("error!\n");
            console.error(err.message);
            res.send('이미지 파일을 찾을 수 없음.');
        });


        //
        //const stat = util.promisify(fs.stat);
        // stat(`${targetPath}`).then((stats)=>{
        //     if(stats.isFile())console.log("Movie info is successfully registered.\n");
        //     else console.log("Movie info is not registered. Poster_URL is wrong."); res.send('HTTP 요청 실패 3');
        // }).catch(error=>{
        //      console.log("error! Movie info is not registered.\n");
        //     // console.error(err.message);
        //     res.send('HTTP 요청 실패 2');
        // });


        //
        // function a(URL){
        // return new Promise(function(resolve,reject){
        //     fs.stat(`${URL}`, (err,stats)=>{
        //         if(stats.isFile()===false){reject(new Error("wow"));}
        //         else{resolve();}
        //     });
        // });
        // }
        //
        // var stat2 = a(targetURL);
        // stat2.then(function (){
        //     console.log("no error");
        // });
        // stat2.catch(function (){
        //     console.log("error");
        // });


    }
});


module.exports = router;
