var express = require('express');
var router = express.Router();

/* POST home page. */
router.post('/result', function(req, res, next) {
    console.log("post result 실행");
    res.render('result.pug', {data: req.body });
});

router.get('/', function(req, res, next) {
    res.render('index.pug');
});


module.exports = router;
