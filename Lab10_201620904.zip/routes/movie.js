const Movie = require('../models/movie');

var express = require('express');
var router = express.Router();


router.post('/routes/movie/create',function(req, res, next) {
    console.log("영화 저장\n");
    console.log(req.body.title);
    const movie = new Movie({
        title: req.body.title,
        year: req.body.year,
        url: req.body.url
    });
    movie.save((err) => {
        res.redirect('/');
    });
});



module.exports = router;