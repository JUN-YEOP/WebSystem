var TodoId = 0

console.log(TodoId);

export const createTodo = text => ({
    type: 'CREATE_TODO',
    id: TodoId++,
    text
})

export const deleteTodo = text => ({
    type: 'DELETE_TODO',
    text
})

export const toggleTodo = id => ({
    type: 'TOGGLE_TODO',
    id
})

