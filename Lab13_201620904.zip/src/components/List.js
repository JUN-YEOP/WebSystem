import React, {Component} from 'react';
import {deleteTodo, toggleTodo} from "../actions/todo";
import PropTypes from 'prop-types'
import {connect} from "react-redux";

// const List = ({onToggle, onDelete}) => (
//     <ul>
//         <li>Todo
//             <span> </span>
//             <button onClick={onToggle}>완료</button>
//             <button onClick={onDelete}>삭제</button>
//         </li>
//     </ul>
// )

// List.prototype = {
//     onToggle: PropTypes.func.isRequired,
//     onDelete: PropTypes.func.isRequired
// }

export class List extends Component {

    render() {
        let {todos} = this.props;
        let {onToggle} = this.props;
        let {onDelete } = this.props;
        // let {totalCount} = this.props;
        // let {doneCount} = this.props;

        const TodoList= todos.todos.map(todo=>{
            return (
                    <li  key={todo.id} {...todo} style={{background: todo.DONE ? "green" : "white"}}>
                        <span>{todo.text}</span>
                        <button onClick={() => onToggle(todo.id)}>완료</button>
                        <button onClick={() => onDelete(todo.text)}>삭제</button>
                    </li>
                )
        });

        return(
            <ul>
                {TodoList}
            </ul>
        )
}}

List.propTypes = {
    onToggle: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    todos: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.number.isRequired,
        DONE: PropTypes.bool.isRequired,
        text: PropTypes.string.isRequired,
    }).isRequired).isRequired,
    // totalCount: PropTypes.number.isRequired,
    // doneCount:  PropTypes.number.isRequired
}

const mapStateToProps = (state) =>({
    todos: state.todo
    // totalCount: state.totalCount,
    // doneCount:state.doneCount
})

const mapDispatchToProps = (dispatch) => ({
    onToggle: (id) => dispatch(toggleTodo(id)),
    onDelete: (text) => dispatch(deleteTodo(text))
})

export default connect(mapStateToProps,mapDispatchToProps)(List)