import React, { Component } from 'react'
import Form from "./Form";
import List from "./List";
import PropTypes from 'prop-types'
import {connect} from "react-redux";

// import store from '../index'



// const TodoList = (totalCount = 0, doneCount = 0) => (
//     <div>
//         {/*<span>total :{totalCount}, done : {doneCount}</span>*/}
//         <Form
//         onCreate={()=> store.dispatch({type:'CREATE_TODO'})}/>
//         <List />
//     </div>
// )
//
// TodoList.propTypes = {
//     totalCount: PropTypes.number.isRequired,
//     doneCount: PropTypes.number.isRequired,
//     // DONE: PropTypes.bool.isRequired
// }
export class TodoList extends Component{

    constructor(props) {
        super(props);
    }
    render(){
        const {count} = this.props;
        // const {todos} = this.props;

        return(
            <div>
                <span>total : {count.totalCount}, done : {count.doneCount}</span>
                <Form />
                <List />
                {/*<ul>{todoEls}</ul>*/}
            </div>
        )
    }

}

TodoList.propTypes = {
   count:PropTypes.number.isRequired
}


const mapStateToProps = (state) =>({
    count : state.todo
})


// const mapDispatchToProps = (dispatch) => ({
//     onCreate: (text) => dispatch(createTodo(text))
// })


export default connect(mapStateToProps, null)(TodoList)

