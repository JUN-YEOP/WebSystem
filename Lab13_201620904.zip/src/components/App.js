import React, {Component} from 'react';
import Header from './Header';
import TodoList from './TodoList';
// import store from '../index';

// import { configureStore } from '@reduxjs/toolkit'
// const store = configureStore('./reducer')

//
// function App() {
//     return (
//         <div className="App">
//             <Header/>
//             <TodoList/>
//         </div>
//     );
// }

export default class App extends Component {
    render() {
        return (
            <div className="App">
                <Header/>
                <TodoList

                // totalCount={getState()}
                // doneCount={store.getState()}
                />
            </div>
        )
    }


};
