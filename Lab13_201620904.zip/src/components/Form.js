import React, {Component} from 'react';
import {createTodo} from "../actions/todo";
import PropTypes from 'prop-types'
import { connect } from 'react-redux'



export  class  Form extends Component {

    constructor(props) {
        super(props);
        this.inputTodo = document.getElementById('inputTodo');
        // this.onCreate = this.onCreate.bind(this);
    }
    // onCreate(e){
    //     // e.preventDefault();
    //     // // const {createTodo} = this.props;
    //     // // createTodo{this.inputTodo.value};
    //     // dispatch({type: 'CREATE_TODO', text: this.inputTodo.value })
    //     // this.inputTodo.value = '';
    // }

    render() {
        let input;
        let {onCreate} = this.props;
        return (
            // <div>
            //     <form>
            //         <input id='inputTodo' placeholder="Enter"/>
            //         <button type='submit' onClick={()=>onCreate(this.inputTodo.value)}>OK</button>
            //     </form>
            // </div>

            <div>
                <form onSubmit={e => {
                    e.preventDefault()
                    if (!input.value.trim()) {
                        return
                    }
                    onCreate(input.value)
                    input.value = ''
                }}>
                    <input ref={node => input = node} placeholder={"Enter"}/>
                    <button type="submit">
                        OK
                    </button>
                </form>
            </div>
        )
    }
};


Form.proptype = {
    onCreate: PropTypes.func.isRequired
};

const mapDispatchToProps = (dispatch) => ({
    onCreate: (text) => dispatch(createTodo(text))
})

export default connect(null, mapDispatchToProps)(Form)
