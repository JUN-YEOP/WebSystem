import React, {Component} from 'react';


const Header = () => (
    <div>
        <h1>
            Lab13_201620904
        </h1>
        <h2>TodoList</h2>
    </div>

)
export default Header