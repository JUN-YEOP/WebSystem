const initialState = {
    todos: [],
    totalCount: 0,
    doneCount: 0,
    // flag: true

}
const todo = (state = initialState, action) => {
    // alert("REDUCER!!");
    // alert(action.type);
    // alert(state);
    // console.log(state);
    console.log(action.type);

    switch (action.type) {

        case 'CREATE_TODO':
            console.log(state);
            return {
                todos: [...state.todos,
                    {
                        id: action.id,
                        text: action.text,
                        DONE: false
                    }
                ],
                totalCount: state.totalCount + 1,
                doneCount: state.doneCount
            }

        // 같은 이름이 2개 이상인 경우 count 개수가 맞지 않음
        case 'DELETE_TODO':
            // alert("DELETE!!");
            // console.log(state);
            console.log(state.todos.map(todo => todo.text === action.text));
            // if (state.todos.map(todo => todo.text === action.text & todo.DONE === true) && state.doneCount>0){
            // if (state.todos.filter(todo => todo.text === action.text)[0].DONE === true) {
            if (state.todos.filter(todo => todo.text === action.text).some(check => check.DONE === true)) {
                return {
                    todos: [
                        ...state.todos.filter(todo => todo.text !== action.text)
                    ],
                    // 같은 이름이 2개 이상인 경우 count 개수가 맞지 않음
                    totalCount: state.totalCount - 1,
                    doneCount: state.doneCount - 1
                }
            } else {
                return {
                    todos: [
                        ...state.todos.filter(todo => todo.text !== action.text)
                    ],
                    // 같은 이름이 2개 이상인 경우 count 개수가 맞지 않음
                    totalCount: state.totalCount - 1,
                    doneCount: state.doneCount
                }
            }


        case 'TOGGLE_TODO':
            // alert("TOGGLE!!");
            console.log(state);
            // state[0].doneCount+1;
            if (state.todos.filter(todo => todo.id === action.id).some(check => check.DONE === false)) {
                return {
                    todos: [
                        ...state.todos.map(todo => (todo.id === action.id) ? {...todo, DONE: !todo.DONE} : todo)
                    ],
                    totalCount: state.totalCount,
                    doneCount: state.doneCount + 1
                }
            } else {
                return {
                    todos: [
                        ...state.todos.map(todo => (todo.id === action.id) ? {...todo, DONE: !todo.DONE} : todo)
                    ],
                    totalCount: state.totalCount,
                    doneCount: state.doneCount - 1
                }

            }


        default:
            return state
    }
}
export default todo