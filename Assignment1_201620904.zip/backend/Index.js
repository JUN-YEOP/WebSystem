var http = require('http');
var fs = require('fs');
var url = require('url');
var path = require('path');
var cur_path = path.resolve('../fs');
var qs = require('querystring');

var file_name = "";
var file_content = "";
var dir_name = "";


var app = http.createServer(function (request, response) {
        var _url = request.url;
        var queryData = url.parse(_url, true).query;
        var pathname = url.parse(_url, true).pathname;

        if (pathname === '/') {
            fs.readFile("../frontend/template.html", function (err, tmpl) {
                fs.readdir(cur_path, function (err, data) {


                    var size;
                    var mtime;
                    var lsinfo = "Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Size  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Modification Date";

                    lsinfo += "<li style='background: aqua'> <span onclick='cd(this);'>..</span></li>"
                    // var info_read = "";

                    data.forEach(function (element) {

                        //dir
                        if (fs.lstatSync(cur_path + '/' + element).isDirectory()) {
                            mtime = fs.lstatSync(cur_path + '/' + element).mtime.toISOString().replace(/T/, ' ').replace(/\..+/, '');
                            lsinfo += "<li style='background: aqua'> " +
                                "<span onclick='cd(this);'>" + element + "</span>" + "&nbsp;&nbsp;       " +
                                //"<input type = 'button' value='delete'/> &nbsp;&nbsp; " +
                                "<button onclick='rmdir(this);' value = '" + element + "'>delete</button>   &nbsp;&nbsp;   " +
                                "<button onclick='rename(this);' value = '" + element + "'>rename</button>   &nbsp;&nbsp;" +
                                " - &nbsp;&nbsp;" + mtime +
                                "</li>";
                        }

                        //file
                        else if (fs.lstatSync(cur_path + '/' + element).isFile()) {
                            size = fs.lstatSync(cur_path + '/' + element).size;
                            mtime = fs.lstatSync(cur_path + '/' + element).mtime.toISOString().replace(/T/, ' ').replace(/\..+/, '');
                            lsinfo += "<li style='background: rebeccapurple'> " +
                                "<span onclick='readfile(this);'>" + element + "</span>" + "&nbsp;&nbsp;" +
                                "<button onclick='rmFile(this);' value = '" + element + "'>delete</button>&nbsp;&nbsp;" +
                                "<button onclick='rename(this);' value = '" + element + "'>rename</button>   &nbsp;&nbsp;" +
                                size + " B &nbsp;&nbsp;" +
                                mtime +
                                "</li>";
                        }
                    })
                    var html = tmpl.toString().replace('%', lsinfo);

                    html = html.replace('?', file_name);
                    html = html.replace('$', file_content);
                    response.writeHead(200, {'Content-Type': 'text/html'});
                    response.end(html);
                });
            });
        } else if (pathname === '/readfile') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;

              // console.log("readfile body 체크 " + body);

            });
            request.on('end', function () {
                let post = qs.parse(body);
                file_name = post.file_name;
                // console.log(file_name);
                let file_path = path.join(cur_path, file_name);
                fs.readFile(file_path, 'utf8', function (err, data) {
                    // console.log(file_path+"에 존재하는 데이터, "+data);
                    file_content = data;

                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');
                });
            });
        }
        // else if (pathname === '/writefile') {
        //     let body = '';
        //     request.on('data', function (data) {
        //         body = body + data;
        //     });
        //     request.on('end', function () {
        //         var post = qs.parse(body);
        //         var title = post.title;
        //         var description = post.description;
        //         var file_path = path.join(cur_path, title);
        //         fs.writeFile(file_path, description, function (err) {
        //             response.writeHead(302, {Location: `http://localhost:3000/`});
        //             response.end('success');
        //         });
        //     });
        // }
            else if (pathname === '/rmFile') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
                // console.log("rmFile body 체크 " + data);
                // console.log("rmFile body 체크 " + body);
            });
            request.on('end', function () {
                let post = qs.parse(body);
                var file_name1 = post.file_name;
                // console.log(post);
                // console.log(file_name1 + "파일삭제!!!!!!!!!!!!!\n");
                let file_path = path.join(cur_path, file_name1);
                // console.log(file_path);
                fs.unlink(file_path, function (err) {
                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');
                });
            });
        }
        else if (pathname === '/rmdir') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
            });
            request.on('end', function () {
                let post = qs.parse(body);
                file_name = post.file_name;
                let file_path = path.join(cur_path, file_name);
                fs.rmdir(file_path, function (err) {
                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');
                });
            });

        } else if (pathname === '/mkdir') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
            });

            request.on('end', function () {
                var post = qs.parse(body);
                var title = post.title;
                var dir_path = path.join(cur_path, title);
                fs.mkdir(dir_path, function (err) {
                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');
                });
            });
        } else if (pathname === '/cd') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
            });

            request.on('end', function () {
                var post = qs.parse(body);
                var dir_name = post.dir_name;
                // console.log(dir_name);
                var dir_path = path.join(cur_path, dir_name);
                cur_path = dir_path;
                response.writeHead(302, {Location: `http://localhost:3000/`});
                response.end('success');
            });
        } else if (pathname === '/rename') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
            });

            request.on('end', function () {
                var post = qs.parse(body);
                var newTitle = post.new_title;
                var ogTitle = post.original_title;

                // console.log(+"\n");

                var og_path = path.join(cur_path, ogTitle);
                var new_path = path.join(cur_path, newTitle);

                // console.log(ogTitle + "\n");
                // console.log(newTitle + "\n");
                // console.log(og_path + "\t" + new_path);

                fs.rename(og_path, new_path, function (err) {
                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');
                });
            });
        } else if (pathname === '/editfile') {
            let body = '';
            request.on('data', function (data) {
                body = body + data;
            });
            request.on('end', function () {
                var post = qs.parse(body);
                var title = post.title;
                var desc = post.description;
                var file_path = path.join(cur_path, title);


                // console.log("edit 파일에서 "+ title);
                // console.log("edit 파일에서 "+ desc);

                fs.writeFile(file_path, desc, {encoding:"utf-8", flag:"w"},function (err) {

                    file_content = desc;
                    // console.log("edit 파일에서 body : "+ body);
                    response.writeHead(302, {Location: `http://localhost:3000/`});
                    response.end('success');

                    // console.log(file_path);
                    // file_content = data;
                    // response.writeHead(302, {Location: `http://localhost:3000/`});
                    // response.end('success');
                });

            });

        }
    }
);

app.listen(3000);